import { BrowserModule } from '@angular/platform-browser';
import { Component, NgModule } from '@angular/core';
import { HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { RecipeComponent } from './recipe/recipe.component';
import { RecipeListComponent } from './recipe/recipe-list/recipe-list.component';
import { RecipeDetailComponent } from './recipe/recipe-detail/recipe-detail.component';
import { RecipeItemComponent } from './recipe/recipe-list/recipe-item/recipe-item.component';
import { ShopingListComponent } from './shoping-list/shoping-list.component';
import { ShopingEditComponent } from './shoping-list/shoping-edit/shoping-edit.component';
import { DropdownDirective } from './dropdown.directive';
import { RecipesService } from './recipe/recipes.service';
import { ShopingListsService } from './shoping-list/shoping-lists.service';
import { RouterModule, Routes, ROUTES } from '@angular/router';
import { RecipeStartComponent } from './recipe/recipe-start/recipe-start.component';
import { RecipeEditComponent } from './recipe/recipe-edit/recipe-edit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { from } from 'rxjs';
import { AuthComponent } from './auth/auth/auth.component';
import { LoadingspinnerComponent } from './shared/loading-spinner/loadingspinner/loadingspinner.component';

const approutes:Routes = [
 {path:'', redirectTo: '/recipe',pathMatch: 'full'},
 {path: 'recipe' , component: RecipeComponent, children: [ 
  {path: '', component: RecipeStartComponent},
  {path: 'new',component: RecipeEditComponent},
  {path: ':id', component: RecipeDetailComponent},
   {path: ':id/edit',component: RecipeEditComponent}
 ]
 
},
 {path: 'shoping-list' , component: ShopingListComponent},
 {path: 'auth',component: AuthComponent }
 


];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    RecipeComponent,
    RecipeListComponent,
    RecipeDetailComponent,
    RecipeItemComponent,
    ShopingListComponent,
    ShopingEditComponent,
    DropdownDirective,
    RecipeEditComponent,
    AuthComponent,
    LoadingspinnerComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    [RouterModule.forRoot(approutes)]
  ],
  providers: [RecipesService,ShopingListsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
