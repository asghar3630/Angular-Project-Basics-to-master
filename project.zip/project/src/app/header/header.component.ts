import { Component, EventEmitter, Output,OnInit } from '@angular/core'
import { DataSorageService } from '../shared/data-sorage.service';



@Component({
    selector: 'app-header',
    templateUrl: './header.component.html'
})

export class HeaderComponent {
    // @Output() featureslect = new EventEmitter<string> ();
    // onslect(feature: string){
    //     this.featureslect.emit(feature);
        

    // }
    constructor(private datastorage: DataSorageService) {

    }
    onsavedata() {
        this.datastorage.storerecipe();

    }
    
}