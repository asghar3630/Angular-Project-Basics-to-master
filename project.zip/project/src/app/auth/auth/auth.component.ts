import { NgForOf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs';
import { authresponsedata, AuthService } from '../auth.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {
  isloginmode = true;
  isloadingmode = false;
  error:string = null;
  constructor(private authservise: AuthService) { }

  onswitchmode() {
    this.isloginmode = !this.isloginmode;
  }
  onsubmit(form:NgForm)
  {
    
    if(!form.valid) {
      return;
    }

    const email = form.value.email;
   const password = form.value.password;
   let authobs: Observable<authresponsedata>
   this.isloadingmode= true;
    if(this.isloginmode) {
    //  authobs = 
      this.authservise.login(email, password)

      
    }
    else {
     authobs=  this.authservise.signup(email,password) 
    //  .subscribe(
    //     responcedata => {
    //       console.log(responcedata);
    //       this.isloadingmode = false;
    //     },
    //     error => {
    //       console.log(error);
    //       this.error = 'An Error Occured!';
    //       this.isloadingmode = false;

    //     }
    //   );

    }

    authobs.subscribe(
      responcedata => {
        console.log(responcedata);
        this.isloadingmode = false;
      },
      error => {
        console.log(error);
        this.error = 'An Error Occured!';
        this.isloadingmode = false;

      }
    );

  
  
    form.reset();

  }

  ngOnInit() {
  }

}
