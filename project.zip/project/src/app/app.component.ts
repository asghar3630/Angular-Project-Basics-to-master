import { Component } from '@angular/core';
import { RecipesService } from './recipe/recipes.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [RecipesService]
})
export class AppComponent {
  // loadfeat = 'recipe';
  // onnaviaget(feature: string)
  // {
  //   this.loadfeat = feature;
  // }

  
 
}
