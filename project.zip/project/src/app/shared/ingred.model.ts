export class Ingred {
   
    constructor( public name: string, public amount:number) { }     
      

}