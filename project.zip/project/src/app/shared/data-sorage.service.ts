import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RecipesService } from '../recipe/recipes.service';

@Injectable({
  providedIn: 'root'
})
export class DataSorageService {

  constructor(private http: HttpClient, private recipeservise: RecipesService) { }
  storerecipe(){
    const recipe = this.recipeservise.getrecipee();
    this.http.put('https://courseproject-8a254.firebaseio.com/recipe.json', recipe).toPromise()
  }
}
