import { Injectable } from '@angular/core';
import { Ingred } from '../shared/ingred.model';
import { ShopingListsService } from '../shoping-list/shoping-lists.service';
import { Recipe } from './recipe.model';

@Injectable({
  providedIn: 'root'
})
export class RecipesService {
  private recipes : Recipe[] = [
    new Recipe ('Steack Recipe','Yummy Steack with cheese and butter and bundle of sauces','https://lifemadesweeter.com/wp-content/uploads/Steak-and-Potatoes-Recipe-Picture-Photo-1-of-1.jpg',[ 
      new Ingred('Meat', 5),
      new Ingred('French Fries', 4)
    ]),
    new Recipe ('Chicken Pieces','Crispy chicken piece very delicious and served with crispy Fries','https://image.freepik.com/free-photo/close-up-fast-food-meal_23-2148273062.jpg',[ 
      new Ingred('Buns', 5),
      new Ingred('Cookies' ,4)
    ]),

    new Recipe ('Vagitable Recipe','Fresh and healthy Vagitable for fresh Vegitable dishes','https://www.selectscience.net/images/articles/Veg-market---Copyright-Adisa.jpg',[ 
      new Ingred('Meat', 10),
      new Ingred('French Fries' ,40)
    ]),
    new Recipe ('Chinees Food Recipee','This is chinees food recipee with ','http://listtoday.org/wallpaper/2015/12/famous-chinese-foods-33-high-resolution-wallpaper.jpg',[
      new Ingred('Meat-chicken', 5),
      new Ingred('Fries', 4)
    ])
   
  ];
  getrecipee( ) {
    return this.recipes.slice();
  }
  getreicpeid(index: number){
    // return this.recipes.slice()[index];
    return this.recipes[index];
  }
 addingreedtoshopinglist(ingreds:Ingred[]){
   this.shopinglistservise.addingreeds(ingreds);


 }
  constructor(private shopinglistservise: ShopingListsService) { }
}
