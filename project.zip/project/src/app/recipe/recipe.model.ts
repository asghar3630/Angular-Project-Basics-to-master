import { Ingred } from '../shared/ingred.model';

export class Recipe {
    public name : string;
    public description : string;
    public imgpath : string;
    public ingred: Ingred[];

    constructor(name:string,desc : string,imgpath:string, ingred : Ingred[])
    {
           this.name=name;
           this.description=desc;
           this.imgpath=imgpath;
           this.ingred = ingred;
    }
}