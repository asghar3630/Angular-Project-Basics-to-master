import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Recipe } from '../recipe.model';
import { RecipesService } from '../recipes.service';

@Component({
  selector: 'app-recipe-detail',
  templateUrl: './recipe-detail.component.html',
  styleUrls: ['./recipe-detail.component.css']
})
export class RecipeDetailComponent implements OnInit {
//  @Input()
  recipe:Recipe;
  id:number;

  constructor(private recipeservise: RecipesService, private route: ActivatedRoute,private router: Router) { }

  ngOnInit(): void {
    // const id = this.route.snapshot.params['id'];
    this.route.params.subscribe(

      (params:Params) => {
        this.id = +params['id'] ;        // + conver string to number in this case
        this.recipe = this.recipeservise.getreicpeid(this.id);
      }

    );
  }

  onaddtoshopinglist(){
    this.recipeservise.addingreedtoshopinglist(this.recipe.ingred);

  }
  oneditrecipe() {
    this.router.navigate(['edit'], { relativeTo: this.route});

  }

}
