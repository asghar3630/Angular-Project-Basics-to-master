import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { Recipe } from '../recipe.model';
import { RecipesService } from '../recipes.service';

@Component({
  selector: 'app-recipe-edit',
  templateUrl: './recipe-edit.component.html',
  styleUrls: ['./recipe-edit.component.css']
})
export class RecipeEditComponent implements OnInit {
  id: number;
  editmode: false;
  recipeform:FormGroup;

  constructor(private route:ActivatedRoute, private recipesevise: RecipesService) { }

  ngOnInit(): void {
    this.route.params.subscribe(
      (params: Params)=> {
        this.id = +params['id'];
        // this.editmode = params['id'] != null;
        // this.initform();

      }
    );
  }
  onsubmit(){
    console.log(this.recipeform);

  }
// private initform() {
//   let recipename = '';
//   let rcpimagepath = '';
//   let rcpdescription = '';
//   if(this.editmode)
//   {
//     const recipe = this.recipesevise.getrecipee(this.id);
//     recipename = recipe.name;
//     rcpimagepath = recipe.imgpath;
//     rcpdescription = recipe.description;


//   }
//   this.recipeform = new FormGroup({
//    'name' : new FormControl(recipename),
//    'imgpate' : new FormControl(rcpimagepath),
//    'description' : new FormControl(rcpdescription),
  

//   });

// }
}
