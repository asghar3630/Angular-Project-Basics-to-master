import { Injectable } from '@angular/core';
import { Ingred } from '../shared/ingred.model';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShopingListsService {
  startedit = new Subject<number>();
  staredit$ = this.startedit.asObservable();
  ingredchange = new Subject<Ingred> ();
 private ingred : Ingred[] = [
    new Ingred('Apple', 10),
    new Ingred('Tomato',40),
    new Ingred('Bnana', 10),
   
  ];
 getingred(){
   return this.ingred;

 }
 getnewingred(index:number)
 {
   return this.ingred[index];
 }

 addingred(ingreds:Ingred ){
   this.ingred.push(ingreds);
  //  this.ingredchange.next(this.ingred.slice());

 }
 addingreeds(ingreeds: Ingred[]) {
   for(let ingredient of ingreeds)
   {
     this.addingred(ingredient);
  }

// this.ingred.push(...ingreeds);
// this.ingredchange.emit(this.addingreeds.slice())
  }
  // updateingrd (index:number,newingr:Ingred) 
  // {
  //  this.ingred[index] = newingr;
  //  this.ingredchange.next(this.ingred.slice)
  // }

 constructor() { }


}
