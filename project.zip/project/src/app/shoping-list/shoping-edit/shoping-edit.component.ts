import { Component,  OnDestroy,  OnInit, ViewChild, } from '@angular/core';
import { NgForm } from '@angular/forms';
import { from, Subscription } from 'rxjs';
import { Ingred } from 'src/app/shared/ingred.model';
import { ShopingListsService } from '../shoping-lists.service';


@Component({
  selector: 'app-shoping-edit',
  templateUrl: './shoping-edit.component.html',
  styleUrls: ['./shoping-edit.component.css']
})
export class ShopingEditComponent implements OnInit, OnDestroy {
  // @ViewChild('nameinput') nameinputref:ElementRef;
  // @ViewChild('amountinput') nameamountref:ElementRef;

 //@Output ingrdadded: EventEmitter< {name:string,amount: number} > ();
 
 @ViewChild('f') slform:NgForm;
 subscription:Subscription;
 editmode = false;
 editindex:number;
 edititem:Ingred;

  constructor(private shopinglist: ShopingListsService) { }

  ngOnInit(): void {
    this.subscription =this.shopinglist.staredit$.subscribe(
      (index) => {
        this.editmode=true;
        this.editindex = index;
          this.edititem = this.shopinglist.getnewingred(index);
          this.slform.setValue( {
            name: this.edititem.name,
            amount:this.edititem.amount,
          
          })
      }

    );
  }
  
 
  onadditem(form:NgForm) {
    // const ingname = n;
    // const ingamount = m;
    const value = form.value;
    const newingred = new Ingred(value.name, value.amount);
    this.shopinglist.addingred(newingred);
    // if(this.editmode) {
    //   this.slform.updateingrd(this.editindex,newingred);
    // }
    // else {
     
    // }

    
    form.reset();

  }
  onclear(){
    this.slform.reset();
    this.editmode = false;
  }
  ondlete() {
    this.onclear();

  }
  ngOnDestroy()
  {
    this.subscription.unsubscribe();
  }



}
