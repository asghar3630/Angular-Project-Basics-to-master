import { Component, OnInit } from '@angular/core';
import { Ingred } from '../shared/ingred.model';
import { ShopingListsService } from './shoping-lists.service';

@Component({
  selector: 'app-shoping-list',
  templateUrl: './shoping-list.component.html',
  styleUrls: ['./shoping-list.component.css']
})
export class ShopingListComponent implements OnInit {

  ingred : Ingred[];
  
  constructor(private shopinglist: ShopingListsService) { }

  ngOnInit(): void {
    this.ingred = this.shopinglist.getingred();
    
      

    
  }

  Edititem(index:number){
    debugger
    this.shopinglist.startedit.next(index);


  }

  
}
